/**
 * 
 */
package com.sun.faban.driver.transport.asynchronous;

/**
 * @author Noah Campbell
 *
 */
public class MissingDyeException extends Exception {

	/** serialVersionUID */
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 */
	public MissingDyeException() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 */
	public MissingDyeException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param cause
	 */
	public MissingDyeException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 * @param cause
	 */
	public MissingDyeException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
