/**
 * 
 */
package com.sun.faban.driver.transport.asynchronous;

/**
 * @author Noah Campbell
 *
 */
public class DyeingException extends Exception {

	/** serialVersionUID */
	private static final long serialVersionUID = 1L;

	/**
	 * 
	 */
	public DyeingException() {
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 */
	public DyeingException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param cause
	 */
	public DyeingException(Throwable cause) {
		super(cause);
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param message
	 * @param cause
	 */
	public DyeingException(String message, Throwable cause) {
		super(message, cause);
		// TODO Auto-generated constructor stub
	}

}
